﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using Mysqlx.Connection;
using MySqlX.XDevAPI.Relational;

namespace WindowsFormsApp1
{
    public partial class ModifyPrices : Form
    {
        MySqlConnection con = new MySqlConnection(@"datasource=127.0.0.1;port=3306;username=root;password=;database=napelem");
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable table;
        public ModifyPrices()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)      //Hozzáad
        {

            // MySqlConnection con = new MySqlConnection(@"datasource=127.0.0.1;port=3306;username=root;password=;database=napelem");
            MySqlCommand cmd = new MySqlCommand("INSERT INTO Alkatreszek(ANev, Maxdb, Darab, Ar) VALUES (@ANev, @Maxdb, @Darab, @Ar)", con);

            cmd.Parameters.AddWithValue("@ANev", textBox2.Text);    //Anev
            cmd.Parameters.AddWithValue("@Maxdb", textBox3.Text);   //Maxdb
            cmd.Parameters.AddWithValue("@Darab", textBox5.Text);   //Db
            cmd.Parameters.AddWithValue("@Ar", textBox7.Text);      //Ár

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

    }
}
